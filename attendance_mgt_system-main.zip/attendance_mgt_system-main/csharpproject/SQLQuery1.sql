﻿select * from teacher where name = piyush;
