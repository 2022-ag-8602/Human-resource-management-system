# attendance_mgt_system

Attendance management system is a project that deals with the maintenance of the student’s attendance details. It generates the attendance of student on basis of presence in the class. Here the staff or the admin will have complete control of entering and modifying the attendance of the student , while the student will have access to view the his /her attendance in a simplified manner.
